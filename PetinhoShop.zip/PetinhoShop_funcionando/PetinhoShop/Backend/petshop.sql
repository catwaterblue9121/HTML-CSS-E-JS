-- PetinhoShop - Banco de Dados
-- Versão corrigida: coluna id_categoria renomeada para categoria_id (compatível com JPA @JoinColumn)
-- Adicionada coluna imagem na tabela categorias

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET NAMES utf8mb4 */;

-- Banco de dados: `petshop`
CREATE DATABASE IF NOT EXISTS `petshop` CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `petshop`;

-- --------------------------------------------------------
-- Tabela `categorias`
-- --------------------------------------------------------
CREATE TABLE `categorias` (
  `id`        BIGINT(20)   NOT NULL AUTO_INCREMENT,
  `nome`      VARCHAR(100) NOT NULL,
  `descricao` TEXT         DEFAULT NULL,
  `ativo`     TINYINT(1)   DEFAULT 1,
  `imagem`    VARCHAR(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Tabela `produtos`
-- CORREÇÃO: coluna renomeada de `id_categoria` para `categoria_id`
--           para corresponder ao @JoinColumn(name = "categoria_id") da entidade JPA
--           coluna imagem ampliada para LONGTEXT (suporta URLs longas ou base64)
-- --------------------------------------------------------
CREATE TABLE `produtos` (
  `id`            BIGINT(20)     NOT NULL AUTO_INCREMENT,
  `nome`          VARCHAR(150)   NOT NULL,
  `descricao`     TEXT           DEFAULT NULL,
  `preco`         DECIMAL(10,2)  NOT NULL,
  `preco_desconto` DECIMAL(10,2) DEFAULT NULL,
  `imagem`        LONGTEXT       DEFAULT NULL,
  `qtd_estoque`   INT(11)        DEFAULT NULL,
  `ativo`         TINYINT(1)     DEFAULT 1,
  `categoria_id`  BIGINT(20)     DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_categoria` (`categoria_id`),
  CONSTRAINT `fk_categoria`
    FOREIGN KEY (`categoria_id`) REFERENCES `categorias` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Dados de exemplo
-- --------------------------------------------------------
INSERT INTO `categorias` (`nome`, `descricao`, `ativo`, `imagem`) VALUES
('Cachorros',  'Produtos para cães',        1, 'https://images.unsplash.com/photo-1587300003388-59208cc962cb?w=500'),
('Gatos',      'Produtos para gatos',       1, 'https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?w=500'),
('Coelhos',    'Produtos para coelhos',     1, 'https://images.unsplash.com/photo-1583301286816-f4f05e1e8b25?w=500'),
('Répteis',    'Produtos para répteis',     1, 'https://images.unsplash.com/photo-1504450874802-0ba2bcd9b5ae?w=500');

INSERT INTO `produtos` (`nome`, `descricao`, `preco`, `preco_desconto`, `imagem`, `qtd_estoque`, `ativo`, `categoria_id`) VALUES
('Ração Premium Cães', 'Ração premium com vitaminas e minerais para cães adultos', 89.90, 79.90, 'https://images.unsplash.com/photo-1601758174493-bb19f97f4e17?w=400', 50, 1, 1),
('Coleira Ajustável',  'Coleira resistente para cães de todos os portes',           34.90, NULL,  'https://images.unsplash.com/photo-1583337130417-3346a1be7dee?w=400', 30, 1, 1),
('Ração Premium Gatos','Ração completa para gatos com taurina e ômega 3',           69.90, 59.90, 'https://images.unsplash.com/photo-1589924691995-400dc9ecc119?w=400', 40, 1, 2),
('Arranhador Gatos',   'Arranhador com brinquedo interativo para gatos',            49.90, NULL,  'https://images.unsplash.com/photo-1601758228041-f3b2795255f1?w=400', 20, 1, 2),
('Ração Coelhos',      'Ração balanceada com feno e vegetais para coelhos',         29.90, NULL,  'https://images.unsplash.com/photo-1585110396000-c9ffd4e4b308?w=400', 25, 1, 3),
('Terrário Répteis',   'Terrário de vidro com ventilação para répteis',            199.90, 179.90,'https://images.unsplash.com/photo-1504450874802-0ba2bcd9b5ae?w=400', 10, 1, 4);

COMMIT;
