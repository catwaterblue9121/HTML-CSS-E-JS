package com.devsenai2a.petshop.entities;

import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "produtos")	
public class Produto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String nome;

    private String descricao;

    @Column(nullable = false)
    private Double preco;

    @Column(name = "preco_desconto")
    private Double precoDesconto;	

    @Column(columnDefinition = "LONGTEXT")
    private String imagem;

    @Column(name = "qtd_estoque")
    private Integer qtdEstoque;

    @Column(nullable = false)
    private Boolean ativo = true;

    @ManyToOne
    @JoinColumn(name = "categoria_id")
    @JsonIgnoreProperties("produtos")
    private Categoria categoria;

    public Produto() {}

    // getters e setters...

    // GETTERS E SETTERS

    public Long getId() { return id; }

    public String getNome() { return nome; }

    public String getDescricao() { return descricao; }

    public Double getPreco() { return preco; }

    public Double getPrecoDesconto() { return precoDesconto; }

    public String getImagem() { return imagem; }

    public Integer getQtdEstoque() { return qtdEstoque; }

    public Boolean getAtivo() { return ativo; }

    public Categoria getCategoria() { return categoria; }

    public void setId(Long id) { this.id = id; }

    public void setNome(String nome) { this.nome = nome; }

    public void setDescricao(String descricao) { this.descricao = descricao; }

    public void setPreco(Double preco) { this.preco = preco; }

    public void setPrecoDesconto(Double precoDesconto) { this.precoDesconto = precoDesconto; }

    public void setImagem(String imagem) { this.imagem = imagem; }

    public void setQtdEstoque(Integer qtdEstoque) { this.qtdEstoque = qtdEstoque; }

    public void setAtivo(Boolean ativo) { this.ativo = ativo; }

    public void setCategoria(Categoria categoria) { this.categoria = categoria; }
}