package com.devsenai2a.petshop.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import com.devsenai2a.petshop.entities.Produto;

public interface ProdutoRepository extends JpaRepository<Produto, Long> {

    List<Produto> findByCategoriaIdAndAtivoTrue(Long id);
    List<Produto> findByAtivoTrue();

}