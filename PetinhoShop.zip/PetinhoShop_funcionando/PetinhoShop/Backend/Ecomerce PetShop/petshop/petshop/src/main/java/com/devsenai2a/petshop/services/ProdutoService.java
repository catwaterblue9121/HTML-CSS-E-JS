package com.devsenai2a.petshop.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.devsenai2a.petshop.entities.Categoria;
import com.devsenai2a.petshop.entities.Produto;
import com.devsenai2a.petshop.repositories.CategoriaRepository;
import com.devsenai2a.petshop.repositories.ProdutoRepository;

@Service
public class ProdutoService {

    @Autowired
    private ProdutoRepository repository;

    @Autowired
    private CategoriaRepository categoriaRepository;

    // CREATE
    public Produto salvar(Produto produto) {

        if (produto.getCategoria() == null || produto.getCategoria().getId() == null) {
            throw new RuntimeException("Categoria é obrigatória");
        }

        // busca categoria real no banco
        Categoria categoria = categoriaRepository
                .findById(produto.getCategoria().getId())
                .orElseThrow(() -> new RuntimeException("Categoria não encontrada"));

        produto.setCategoria(categoria);

        if (produto.getAtivo() == null) {
            produto.setAtivo(true);
        }

        return repository.save(produto);
    }

    // LIST
    public List<Produto> listar() {
        return repository.findByAtivoTrue();
    }

    // GET BY ID
    public Produto buscarPorId(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Produto não encontrado"));
    }

    // UPDATE
    public Produto atualizar(Long id, Produto produtoAtualizado) {

        Produto existente = buscarPorId(id);

        existente.setNome(produtoAtualizado.getNome());
        existente.setDescricao(produtoAtualizado.getDescricao());
        existente.setPreco(produtoAtualizado.getPreco());
        existente.setPrecoDesconto(produtoAtualizado.getPrecoDesconto());
        existente.setImagem(produtoAtualizado.getImagem());
        existente.setQtdEstoque(produtoAtualizado.getQtdEstoque());

        if (produtoAtualizado.getAtivo() != null) {
            existente.setAtivo(produtoAtualizado.getAtivo());
        }

        if (produtoAtualizado.getCategoria() != null
                && produtoAtualizado.getCategoria().getId() != null) {

            Categoria categoria = categoriaRepository
                    .findById(produtoAtualizado.getCategoria().getId())
                    .orElseThrow(() -> new RuntimeException("Categoria não encontrada"));

            existente.setCategoria(categoria);
        }

        return repository.save(existente);
    }

    // DELETE
    public void deletar(Long id) {
        repository.deleteById(id);
    }

    // CATEGORY FILTER
    public List<Produto> getProdutosPorCategoria(Long id) {
        return repository.findByCategoriaIdAndAtivoTrue(id);
    }
}