// produtosCategoria.js
// CORREÇÃO: adicionarCarrinho() agora vem de carrinho.js (importado no HTML)
//           produto passado com campos corretos da API (imagem, descricao)

const API = "http://localhost:8080/api";

const listaProdutos    = document.getElementById("listaProdutos");
const semProdutos      = document.getElementById("semProdutos");
const tituloCategoria  = document.getElementById("tituloCategoria");

const params      = new URLSearchParams(window.location.search);
const categoriaId = Number(params.get("categoria"));

async function carregarProdutos() {
    try {

        if (!categoriaId) {
            tituloCategoria.textContent = "Categoria inválida";
            semProdutos.classList.remove("hidden");
            return;
        }

        // Busca dados da categoria para exibir o nome no hero
        const categoriasRes = await fetch(`${API}/categorias/${categoriaId}`);
        if (categoriasRes.ok) {
            const categoriaAtual = await categoriasRes.json();
            tituloCategoria.textContent = categoriaAtual?.nome || "Produtos";
        } else {
            tituloCategoria.textContent = "Produtos";
        }

        // Busca produtos da categoria
        const produtosRes = await fetch(`${API}/produtos/categoria/${categoriaId}`);

        if (!produtosRes.ok) {
            throw new Error("Erro ao buscar produtos");
        }

        const produtos = await produtosRes.json();

        listaProdutos.innerHTML = "";

        if (!produtos || produtos.length === 0) {
            semProdutos.classList.remove("hidden");
            return;
        }

        semProdutos.classList.add("hidden");

        produtos.forEach(produto => {

            // preço com desconto ou preço normal
            const precoFinal  = produto.precoDesconto || produto.preco;
            const temDesconto  = produto.precoDesconto && produto.precoDesconto < produto.preco;

            listaProdutos.innerHTML += `
                <div class="bg-white rounded-2xl shadow-md overflow-hidden hover:shadow-lg transition">

                    <div class="h-52 bg-gray-100 flex justify-center items-center cursor-pointer"
                         onclick="verProduto(${produto.id})">
                        <img
                            src="${produto.imagem || 'https://via.placeholder.com/300'}"
                            class="max-h-full object-contain"
                            alt="${produto.nome}"
                            onerror="this.src='https://via.placeholder.com/300'"
                        >
                    </div>

                    <div class="p-4">

                        <h3 class="font-bold text-gray-800 cursor-pointer hover:text-orange-500"
                            onclick="verProduto(${produto.id})">
                            ${produto.nome}
                        </h3>

                        <p class="text-sm text-gray-500 mt-1 line-clamp-2">
                            ${produto.descricao || ""}
                        </p>

                        <div class="mt-3 flex items-center gap-2">
                            <span class="text-orange-500 font-bold text-lg">
                                R$ ${Number(precoFinal).toFixed(2)}
                            </span>
                            ${temDesconto ? `
                            <span class="text-gray-400 line-through text-sm">
                                R$ ${Number(produto.preco).toFixed(2)}
                            </span>` : ""}
                        </div>

                        <div class="flex gap-2 mt-4">
                            <button
                                onclick='adicionarCarrinho(${JSON.stringify(produto)})'
                                class="flex-1 bg-orange-500 text-white py-2 rounded-xl hover:bg-orange-600 transition"
                            >
                                🛒 Comprar
                            </button>
                            <button
                                onclick="verProduto(${produto.id})"
                                class="px-3 border border-orange-400 text-orange-500 rounded-xl hover:bg-orange-50 transition"
                            >
                                Ver
                            </button>
                        </div>

                    </div>
                </div>
            `;
        });

    } catch (err) {
        console.error("Erro ao carregar produtos:", err);
        tituloCategoria.textContent = "Erro ao carregar";
        semProdutos.classList.remove("hidden");
        semProdutos.textContent = "Erro ao carregar produtos. Verifique se o backend está rodando.";
    }
}

// Navega para a página de descrição do produto
function verProduto(id) {
    window.location.href = `descricaoprodutos.html?id=${id}`;
}

carregarProdutos();
