// produtos.js — painel admin de produtos
// CORREÇÃO: preço exibido com .toFixed(2) para evitar "89.9" em vez de "89,90"

const API  = "http://localhost:8080/api/produtos";
const form = document.getElementById("formProduto");
const lista = document.getElementById("lista");

// =========================
// PREVIEW DE IMAGEM (URL)
// =========================
const inputImagem = document.getElementById("imagem");
const preview     = document.getElementById("preview");
const placeholder = document.getElementById("placeholder");

if (inputImagem) {
    inputImagem.addEventListener("input", atualizarPreview);
}

function atualizarPreview() {
    const url = inputImagem.value.trim();

    if (url) {
        preview.src = url;
        preview.classList.remove("hidden");
        placeholder.classList.add("hidden");
    } else {
        limparPreview();
    }
}

// =========================
// LISTAR PRODUTOS
// =========================
async function listar() {
    try {
        const res = await fetch(API);

        if (!res.ok) throw new Error("Erro ao listar produtos");

        const data = await res.json();

        lista.innerHTML = "";

        if (data.length === 0) {
            lista.innerHTML = `
                <p class="col-span-full text-center text-gray-500 py-10">
                    Nenhum produto cadastrado ainda.
                </p>
            `;
            return;
        }

        data.forEach(p => {
            // CORREÇÃO: preço exibido com .toFixed(2)
            const precoFormatado = Number(p.preco).toFixed(2);

            lista.innerHTML += `
                <div class="bg-white rounded-2xl shadow-md overflow-hidden">

                    <div class="h-40 flex justify-center items-center bg-gray-100">
                        <img src="${p.imagem || 'https://via.placeholder.com/150'}"
                             class="max-h-full object-contain"
                             onerror="this.src='https://via.placeholder.com/150'">
                    </div>

                    <div class="p-4">
                        <h3 class="font-bold text-gray-800">${p.nome}</h3>

                        <p class="text-sm text-gray-500 line-clamp-2">${p.descricao || ""}</p>

                        <div class="mt-2">
                            <span class="text-orange-500 font-bold">
                                R$ ${precoFormatado}
                            </span>
                            ${p.precoDesconto ? `
                            <span class="text-xs text-green-600 ml-1">
                                (desc: R$ ${Number(p.precoDesconto).toFixed(2)})
                            </span>` : ""}
                        </div>

                        <p class="text-sm text-gray-500 mt-1">
                            Estoque: ${p.qtdEstoque ?? "—"}
                        </p>

                        <p class="text-sm text-gray-500">
                            Categoria: ${p.categoria?.nome || "—"}
                        </p>

                        <div class="flex gap-2 mt-4">
                            <button onclick="editar(${p.id})"
                                class="flex-1 bg-blue-500 text-white py-2 rounded-lg hover:bg-blue-600 transition">
                                Editar
                            </button>

                            <button onclick="deletar(${p.id})"
                                class="flex-1 bg-red-500 text-white py-2 rounded-lg hover:bg-red-600 transition">
                                Excluir
                            </button>
                        </div>
                    </div>

                </div>
            `;
        });

    } catch (err) {
        console.error("Erro ao listar:", err);
        lista.innerHTML = `
            <p class="col-span-full text-center text-red-500 py-10">
                Erro ao carregar produtos. Verifique se o backend está rodando na porta 8080.
            </p>
        `;
    }
}

// =========================
// SALVAR (POST ou PUT)
// =========================
form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const idInput = document.getElementById("id");
    const id      = idInput?.value ? Number(idInput.value) : null;

    const categoriaIdVal = Number(document.getElementById("categoriaId").value);
    if (!categoriaIdVal) {
        alert("Informe o ID da categoria.");
        return;
    }

    const produto = {
        nome:          document.getElementById("nome").value.trim(),
        descricao:     document.getElementById("descricao").value.trim() || "",
        preco:         Number(document.getElementById("preco").value),
        precoDesconto: Number(document.getElementById("precoDesconto").value) || null,
        qtdEstoque:    Number(document.getElementById("qtdEstoque").value),
        imagem:        document.getElementById("imagem").value.trim() || null,
        ativo:         true,
        categoria: {
            id: categoriaIdVal
        }
    };

    try {
        const url    = id ? `${API}/${id}` : API;
        const method = id ? "PUT" : "POST";

        const res = await fetch(url, {
            method,
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(produto)
        });

        if (!res.ok) {
            const msg = await res.text();
            throw new Error(msg || "Erro ao salvar produto");
        }

        form.reset();
        limparPreview();
        listar();

    } catch (err) {
        console.error("Erro ao salvar:", err);
        alert("Erro ao salvar: " + err.message);
    }
});

// =========================
// EDITAR
// =========================
async function editar(id) {
    try {
        const res = await fetch(`${API}/${id}`);

        if (!res.ok) throw new Error("Produto não encontrado");

        const p = await res.json();

        document.getElementById("id").value             = p.id || "";
        document.getElementById("nome").value           = p.nome || "";
        document.getElementById("descricao").value      = p.descricao || "";
        document.getElementById("preco").value          = p.preco || 0;
        document.getElementById("precoDesconto").value  = p.precoDesconto || "";
        document.getElementById("qtdEstoque").value     = p.qtdEstoque || 0;
        document.getElementById("categoriaId").value    = p.categoria?.id || "";
        document.getElementById("imagem").value         = p.imagem || "";

        atualizarPreview();
        window.scrollTo({ top: 0, behavior: "smooth" });

    } catch (err) {
        console.error("Erro ao editar:", err);
        alert("Erro ao carregar produto: " + err.message);
    }
}

// =========================
// DELETAR
// =========================
async function deletar(id) {
    if (!confirm("Deseja realmente excluir este produto?")) return;

    try {
        const res = await fetch(`${API}/${id}`, { method: "DELETE" });

        if (!res.ok) throw new Error("Erro ao deletar");

        listar();

    } catch (err) {
        console.error("Erro ao deletar:", err);
        alert("Erro ao excluir: " + err.message);
    }
}

// =========================
// HELPERS
// =========================
function limparPreview() {
    if (preview) {
        preview.src = "";
        preview.classList.add("hidden");
    }
    if (placeholder) {
        placeholder.classList.remove("hidden");
    }
}

// =========================
// INIT
// =========================
listar();
