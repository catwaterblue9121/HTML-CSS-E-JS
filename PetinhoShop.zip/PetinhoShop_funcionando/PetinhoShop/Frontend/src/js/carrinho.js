// ============================================================
// carrinho.js — módulo central do carrinho
// Usado por: produtosAnimais.html, descricaoprodutos.html
// CORREÇÃO: adicionada função adicionarCarrinho() que faltava
//           no arquivo original, causando erro em produtosAnimais.html
// ============================================================

let carrinho = JSON.parse(localStorage.getItem("carrinho")) || [];

// =========================
// ADICIONAR AO CARRINHO
// =========================
function adicionarCarrinho(produto) {
    if (!produto) return;

    // normaliza campos: API usa "imagem" e "descricao"
    // CORREÇÃO: páginas antigas usavam "img" e "desc" — padronizado para "imagem"/"descricao"
    const item = {
        id:        produto.id,
        nome:      produto.nome,
        preco:     Number(produto.precoDesconto || produto.preco),
        imagem:    produto.imagem || "",
        descricao: produto.descricao || ""
    };

    carrinho.push(item);
    localStorage.setItem("carrinho", JSON.stringify(carrinho));
    atualizarContador();
    alert(`"${item.nome}" adicionado ao carrinho! 🛒`);
}

// =========================
// ATUALIZAR CONTADOR NO HEADER
// =========================
function atualizarContador() {
    const count = document.getElementById("cartCount");
    if (count) {
        count.innerText = carrinho.length;
    }
}

// =========================
// REMOVER ITEM
// =========================
function removerItem(index) {
    carrinho.splice(index, 1);
    localStorage.setItem("carrinho", JSON.stringify(carrinho));
    atualizarContador();
    // se a página tem listaCarrinho, re-renderiza
    if (document.getElementById("listaCarrinho")) {
        renderizarCarrinho();
    }
}

// =========================
// RENDERIZAR CARRINHO (usado em carrinho.html)
// =========================
function renderizarCarrinho() {
    const lista      = document.getElementById("listaCarrinho");
    const totalEl    = document.getElementById("total");
    const subtotalEl = document.getElementById("subtotal");

    if (!lista || !totalEl) return;

    lista.innerHTML = "";
    let total = 0;

    if (carrinho.length === 0) {
        lista.innerHTML = `
            <div class="bg-white p-10 rounded-2xl shadow text-center">
                <i class="fa-solid fa-cart-shopping text-4xl text-gray-300 mb-4"></i>
                <p class="text-gray-500 text-lg">Seu carrinho está vazio</p>
                <a href="inicio.html"
                    class="mt-4 inline-block bg-orange-500 text-white px-6 py-2 rounded-lg hover:bg-orange-600 transition">
                    Ver produtos
                </a>
            </div>
        `;
        if (totalEl)    totalEl.innerText    = "R$ 0,00";
        if (subtotalEl) subtotalEl.innerText = "R$ 0,00";
        return;
    }

    carrinho.forEach((p, index) => {
        // CORREÇÃO: código antigo usava p.img — agora usa p.imagem (padrão da API)
        total += Number(p.preco);

        lista.innerHTML += `
            <div class="bg-white p-4 rounded-2xl shadow flex gap-4 items-center hover:shadow-lg transition">

                <div class="w-24 h-24 bg-gray-100 rounded-xl flex items-center justify-center overflow-hidden">
                    <img src="${p.imagem || 'https://via.placeholder.com/100'}"
                         class="max-h-full object-contain p-2"
                         onerror="this.src='https://via.placeholder.com/100'">
                </div>

                <div class="flex-1">
                    <h3 class="font-bold text-gray-800 text-lg">${p.nome}</h3>
                    <p class="text-sm text-gray-500">${p.descricao || ""}</p>
                    <p class="text-orange-500 font-bold mt-2 text-lg">
                        R$ ${Number(p.preco).toFixed(2)}
                    </p>
                </div>

                <button onclick="removerItem(${index})"
                    class="text-red-500 hover:text-red-700 text-sm font-semibold p-2">
                    <i class="fa-solid fa-trash"></i>
                </button>

            </div>
        `;
    });

    if (totalEl)    totalEl.innerText    = "R$ " + total.toFixed(2);
    if (subtotalEl) subtotalEl.innerText = "R$ " + total.toFixed(2);
}

// =========================
// FINALIZAR COMPRA
// =========================
function finalizarCompra() {
    alert("Compra finalizada com sucesso! 🐾 Obrigado pela preferência!");
    carrinho = [];
    localStorage.removeItem("carrinho");
    atualizarContador();
    renderizarCarrinho();
}

// =========================
// INIT
// =========================
atualizarContador();

// se for a página do carrinho, renderiza imediatamente
if (document.getElementById("listaCarrinho")) {
    renderizarCarrinho();
}
