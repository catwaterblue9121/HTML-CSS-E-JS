# PetinhoShop — Correções Aplicadas

## Resumo Geral

O projeto tinha **erros que quebravam completamente a conexão entre frontend e backend**,
além de bugs de roteamento e código duplicado/incompatível.
Abaixo está a lista completa do que foi corrigido.

---

## 🔴 ERROS CRÍTICOS (quebravam o sistema)

### 1. SQL — coluna `id_categoria` vs `categoria_id`
**Arquivo:** `Backend/sql/petshop.sql`  
**Problema:** O banco de dados criava a coluna `id_categoria`, mas a entidade JPA
(`Produto.java`) declarava `@JoinColumn(name = "categoria_id")`. Com isso, o Hibernate
nunca conseguiria salvar ou buscar a relação produto↔categoria.  
**Correção:** Coluna renomeada para `categoria_id` no SQL.

---

### 2. `categorias.js` — link errado nas categorias
**Arquivo:** `Frontend/src/js/categorias.js`  
**Problema:**
```js
// ERRADO — levava para a página de detalhe de UM produto
href="descricaoprodutos.html?categoria=${cat.id}"
```
**Correção:**
```js
// CORRETO — leva para a listagem de produtos daquela categoria
href="produtosAnimais.html?categoria=${cat.id}"
```

---

### 3. `produtosAnimais.html` — `carrinho.js` não era importado
**Arquivo:** `Frontend/produtosAnimais.html`  
**Problema:** A página chamava `adicionarCarrinho()` nos botões "Comprar",
mas o script `carrinho.js` nunca era carregado. Resultado: **erro de JavaScript**
ao clicar em qualquer produto.  
**Correção:** Adicionado `<script src="src/js/carrinho.js"></script>` antes de
`produtosCategoria.js`.

---

### 4. `descricaoprodutos.html` — dependia de `localStorage` com campos errados
**Arquivo:** `Frontend/descricaoprodutos.html`  
**Problema:** A página buscava o produto em `localStorage.getItem("produtoSelecionado")`
com campos `produto.img` e `produto.desc`, que **não existem na API**
(a API retorna `imagem` e `descricao`). Além disso, a navegação para a página
dependia de quem tivesse salvo o produto no localStorage — o que o novo
`produtosCategoria.js` nunca fazia.  
**Correção:** Página reescrita para carregar o produto **diretamente da API**
via `?id=X` na URL (`GET /api/produtos/{id}`). Campos `imagem` e `descricao` corretos.

---

### 5. `carrinho.html` — lógica inline incompatível com a API
**Arquivo:** `Frontend/carrinho.html`  
**Problema:** O carrinho usava `p.img` (campo inexistente na API, que retorna `imagem`)
e código duplicado separado do `carrinho.js`. Produtos adicionados pela nova
`adicionarCarrinho()` não renderizavam a imagem.  
**Correção:** Toda a lógica movida para `carrinho.js`. HTML simplificado com
`<script src="src/js/carrinho.js"></script>`.

---

## 🟡 ERROS MENORES

### 6. `produtosAnimais.html` — link do logo quebrado
**Problema:** `<a href="index.html">` — arquivo `index.html` não existe no projeto.  
**Correção:** `<a href="inicio.html">`

### 7. `produtos.js` — preço sem formatação
**Problema:** Preço exibido como `89.9` em vez de `89,90`.  
**Correção:** `Number(p.preco).toFixed(2)` aplicado.

### 8. `carrinho.html` — atributo `class` duplicado no `<body>`
**Problema:** `<body onload="..." class="..." class="...">` (dois atributos `class`).  
**Correção:** Unificado em um único atributo.

### 9. SQL — `categorias` não tinha coluna `imagem`
**Problema:** A entidade `Categoria.java` tem o campo `imagem`, mas a tabela SQL
não criava essa coluna. O JPA tentaria salvar/ler um campo que não existia.  
**Correção:** Coluna `imagem VARCHAR(500)` adicionada na tabela `categorias`.

### 10. `produtosCategoria.js` — busca desnecessária de todas as categorias
**Problema:** Para exibir o nome da categoria no hero, o código buscava **todas** as
categorias e filtrava localmente, gerando tráfego desnecessário.  
**Correção:** Usa `GET /api/categorias/{id}` diretamente.

---

## ✅ O que NÃO foi alterado (já estava correto)

- `pom.xml` — dependências corretas para Spring Boot 3.3 + Java 17
- `SecurityConfig.java` — CSRF desabilitado, `/api/**` liberado
- `WebConfig.java` — CORS configurado para `allowedOrigins("*")`
- `application.properties` — configuração MySQL na porta 3306
- `Produto.java` / `Categoria.java` — entidades com relacionamento correto
- `ProdutoService.java` / `CategoriaService.java` — lógica de negócio correta
- `ProdutoRepository.java` — métodos `findByAtivoTrue()` e `findByCategoriaIdAndAtivoTrue()` corretos
- `inicio.html`, `login.html`, `cadastro.html`, `perfil.html` — sem erros

---

## 🚀 Como rodar o projeto

### Backend (Spring Boot)
```bash
cd "Backend/Ecomerce PetShop/petshop/petshop"
./mvnw spring-boot:run
```
Requer MySQL rodando na porta 3306 com banco `petshop` criado.  
Configure usuário/senha em `src/main/resources/application.properties`.

### Frontend
Abra `Frontend/inicio.html` no navegador, ou sirva com qualquer servidor HTTP:
```bash
cd Frontend
npx serve .
# ou
python -m http.server 3000
```

### Banco de dados
Execute o arquivo `Backend/sql/petshop.sql` no MySQL para criar as tabelas e dados de exemplo.

---

## Fluxo correto após as correções

```
inicio.html
  └── categorias.js → GET /api/categorias
        └── clica na categoria
              └── produtosAnimais.html?categoria=1
                    └── produtosCategoria.js → GET /api/produtos/categoria/1
                          ├── botão "Comprar" → carrinho.js → localStorage
                          └── botão "Ver" → descricaoprodutos.html?id=5
                                └── GET /api/produtos/5
                                      └── botão "Adicionar ao carrinho" → carrinho.js

carrinho.html
  └── carrinho.js → renderiza itens do localStorage
        └── botão "Finalizar Compra" → limpa carrinho

produtos.html (painel admin)
  └── produtos.js → GET/POST/PUT/DELETE /api/produtos
```
