package com.devsenai2a.petshop.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.devsenai2a.petshop.entities.Produto;
import com.devsenai2a.petshop.repositories.ProdutoRepository;

@Service
public class ProdutoService {

    @Autowired
    private ProdutoRepository repository;

    // CREATE
    public Produto salvar(Produto produto) {

        if (produto.getCategoria() == null || produto.getCategoria().getId() == null) {
            throw new RuntimeException("Categoria é obrigatória");
        }

        if (produto.getAtivo() == null) {
            produto.setAtivo(true);
        }

        return repository.save(produto);
    }

    // LIST
    public List<Produto> listar() {
        return repository.findByAtivoTrue();
    }

    // GET BY ID
    public Produto buscarPorId(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Produto não encontrado"));
    }

    // UPDATE (VERSÃO SEGURA E CORRIGIDA)
    public Produto atualizar(Long id, Produto produtoAtualizado) {

        Produto existente = buscarPorId(id);

        existente.setNome(produtoAtualizado.getNome());
        existente.setDescricao(produtoAtualizado.getDescricao());
        existente.setPreco(produtoAtualizado.getPreco());
        existente.setPrecoDesconto(produtoAtualizado.getPrecoDesconto());
        existente.setImagem(produtoAtualizado.getImagem());
        existente.setQtdEstoque(produtoAtualizado.getQtdEstoque());

        // evita sobrescrever com null
        if (produtoAtualizado.getAtivo() != null) {
            existente.setAtivo(produtoAtualizado.getAtivo());
        }

        // categoria segura
        if (produtoAtualizado.getCategoria() != null &&
            produtoAtualizado.getCategoria().getId() != null) {
            existente.setCategoria(produtoAtualizado.getCategoria());
        }

        return repository.save(existente);
    }

    // DELETE
    public void deletar(Long id) {
        if (!repository.existsById(id)) {
            throw new RuntimeException("Produto não encontrado");
        }
        repository.deleteById(id);
    }

    // CATEGORY FILTER
    public List<Produto> getProdutosPorCategoria(Long id) {
        return repository.findByCategoriaIdAndAtivoTrue(id);
    }
}