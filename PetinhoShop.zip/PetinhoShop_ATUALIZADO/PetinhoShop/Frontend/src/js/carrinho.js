let carrinho = JSON.parse(localStorage.getItem("carrinho")) || [];

// =========================
// ADICIONAR AO CARRINHO
// =========================
function adicionarCarrinho(produto) {
  if (!produto) return;

  carrinho.push(produto);

  localStorage.setItem("carrinho", JSON.stringify(carrinho));

  atualizarContador();

  alert("Produto adicionado ao carrinho!");
}

// =========================
// ATUALIZAR CONTADOR
// =========================
function atualizarContador() {
  const count = document.getElementById("cartCount");
  if (count) {
    count.innerText = carrinho.length;
  }
}

// =========================
// CARREGAR CARRINHO
// =========================
function carregarCarrinho() {
  const lista = document.getElementById("listaCarrinho");
  const totalEl = document.getElementById("total");

  if (!lista || !totalEl) return;

  lista.innerHTML = "";
  let total = 0;

  if (carrinho.length === 0) {
    lista.innerHTML = `
            <p class="text-gray-500 text-center">
                Carrinho vazio
            </p>
        `;
    totalEl.innerText = "Total: R$ 0,00";
    return;
  }

  carrinho.forEach((prod, index) => {
    total += prod.preco;

    lista.innerHTML += `
            <div class="flex justify-between items-center bg-white p-4 rounded shadow">

                <div>
                    <p class="font-semibold">${prod.nome}</p>
                    <p class="text-sm text-gray-500">R$ ${prod.preco.toFixed(2)}</p>
                </div>

                <button onclick="removerItem(${index})"
                    class="text-red-500 hover:text-red-700">
                    <i class="fa-solid fa-trash"></i>
                </button>

            </div>
        `;
  });

  totalEl.innerText = "Total: R$ " + total.toFixed(2);
}

// =========================
// REMOVER ITEM
// =========================
function removerItem(index) {
  carrinho.splice(index, 1);

  localStorage.setItem("carrinho", JSON.stringify(carrinho));

  carregarCarrinho();
  atualizarContador();
}

// =========================
// INIT
// =========================
atualizarContador();
carregarCarrinho();