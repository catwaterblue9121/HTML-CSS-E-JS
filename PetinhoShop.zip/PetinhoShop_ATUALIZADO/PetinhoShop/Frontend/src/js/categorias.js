const API = "http://localhost:8080/api/categorias";

const container = document.getElementById("listaCategorias");

async function carregarCategorias() {

    try {

        const res = await fetch(API);

        if (!res.ok) {
            throw new Error("Erro ao buscar categorias");
        }

        const categorias = await res.json();

        container.innerHTML = "";

        if (!categorias || categorias.length === 0) {

            container.innerHTML = `
                <p class="col-span-full text-center text-gray-500">
                    Nenhuma categoria cadastrada.
                </p>
            `;

            return;
        }

        let html = "";

        categorias.forEach(cat => {

            html += `
            
                <a 
                    href="descricaoprodutos.html?categoria=${cat.id}"
                    class="group bg-white rounded-2xl overflow-hidden shadow hover:shadow-2xl hover:-translate-y-1 transition duration-300"
                >

                    <div class="overflow-hidden">

                        <img 
                            src="${cat.imagem ? cat.imagem : 'https://via.placeholder.com/500x400?text=Categoria'}"
                            alt="${cat.nome}"
                            class="w-full h-56 object-cover group-hover:scale-110 transition duration-500"
                        >

                    </div>

                    <div class="p-5 text-center">

                        <h3 class="text-xl font-bold text-gray-800">
                            ${cat.nome}
                        </h3>

                        <p class="text-sm text-gray-500 mt-2">
                            ${cat.descricao ? cat.descricao : 'Produtos para seu pet'}
                        </p>

                        <button
                            class="mt-4 w-full bg-orange-500 hover:bg-orange-600 text-white py-2 rounded-xl transition"
                        >
                            Ver Produtos
                        </button>

                    </div>

                </a>

            `;
        });

        container.innerHTML = html;

    } catch (erro) {

        console.error("Erro:", erro);

        container.innerHTML = `
            <p class="col-span-full text-center text-red-500">
                Erro ao carregar categorias.
            </p>
        `;
    }
}

carregarCategorias();