function filtrarCategorias() {
    const input = document.getElementById("searchInput").value.toLowerCase();
    const cards = document.querySelectorAll("[data-categoria]");

    cards.forEach(card => {
        const categoria = card.getAttribute("data-categoria");

        if (categoria.includes(input)) {
            card.style.display = "flex";
        } else {
            card.style.display = "none";
        }
    });
}