const API = "http://localhost:8080/api/produtos";

const form = document.getElementById("formProduto");
const lista = document.getElementById("lista");

function listar() {
    fetch(API)
        .then(res => res.json())
        .then(data => {
            lista.innerHTML = "";

            data.forEach(p => {
                lista.innerHTML += `
                    <div class="bg-white rounded-2xl shadow-md overflow-hidden hover:scale-105 transition">

                        <img src="${p.imagem || 'https://via.placeholder.com/300'}"
                            class="w-full h-40 object-cover">

                        <div class="p-4">
                            <h3 class="font-bold text-lg">${p.nome}</h3>
                            <p class="text-sm text-gray-500 mb-2">${p.descricao || ''}</p>

                            <p class="text-gray-400 line-through text-sm">
                                R$ ${p.preco}
                            </p>

                            <p class="text-green-600 text-xl font-bold">
                                R$ ${p.precoDesconto}
                            </p>

                            <p class="text-sm mt-1">Estoque: ${p.qtdEstoque}</p>

                            <div class="flex gap-2 mt-3">
                                <button onclick="editar(${p.id})"
                                    class="flex-1 bg-yellow-400 hover:bg-yellow-500 text-white py-1 rounded-lg">
                                    ✏️
                                </button>

                                <button onclick="excluir(${p.id})"
                                    class="flex-1 bg-red-500 hover:bg-red-600 text-white py-1 rounded-lg">
                                    🗑️
                                </button>
                            </div>
                        </div>
                    </div>
                `;
            });
        })
        .catch(err => {
            console.error("Erro ao listar:", err);
        });
}

form.addEventListener("submit", e => {
    e.preventDefault();

    // 🔴 validação básica
    if (!nome.value || !preco.value) {
        alert("Preencha nome e preço!");
        return;
    }

    if (!categoriaId.value) {
        alert("Informe o ID da categoria!");
        return;
    }

    const produto = {
        nome: nome.value,
        descricao: descricao.value,
        preco: parseFloat(preco.value),
        precoDesconto: precoDesconto.value ? parseFloat(precoDesconto.value) : 0,
        imagem: imagem.value,
        qtdEstoque: qtdEstoque.value ? parseInt(qtdEstoque.value) : 0,
        ativo: true,
        categoria: {
            id: parseInt(categoriaId.value)
        }
    };

    const id = document.getElementById("id").value;

    const metodo = id ? "PUT" : "POST";
    const url = id ? `${API}/${id}` : API;

    fetch(url, {
        method: metodo,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(produto)
    })
        .then(res => {
            if (!res.ok) {
                return res.text().then(text => { throw new Error(text); });
            }
            return res.json();
        })
        .then(() => {
            form.reset();
            listar();
        })
        .catch(err => {
            console.error("ERRO AO SALVAR:", err);
            alert("Erro ao salvar produto. Veja o console (F12).");
        });
});

function editar(id) {
    fetch(`${API}/${id}`)
        .then(res => res.json())
        .then(p => {
            document.getElementById("id").value = p.id;
            nome.value = p.nome;
            descricao.value = p.descricao;
            preco.value = p.preco;
            precoDesconto.value = p.precoDesconto;
            imagem.value = p.imagem;
            qtdEstoque.value = p.qtdEstoque;
            categoriaId.value = p.categoria?.id || "";
        })
        .catch(err => console.error("Erro ao editar:", err));
}

function excluir(id) {
    if (!confirm("Deseja excluir este produto?")) return;

    fetch(`${API}/${id}`, { method: "DELETE" })
        .then(res => {
            if (!res.ok) throw new Error("Erro ao deletar");
            listar();
        })
        .catch(err => console.error("Erro ao excluir:", err));
}

// INIT
listar();