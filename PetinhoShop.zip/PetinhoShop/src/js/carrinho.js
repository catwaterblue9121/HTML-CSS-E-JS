let carrinho = JSON.parse(localStorage.getItem("carrinho")) || [];

function adicionarCarrinho(id) {
    const produto = produtos.find(p => p.id === id);

    carrinho.push(produto);

    localStorage.setItem("carrinho", JSON.stringify(carrinho));

    alert("Produto adicionado ao carrinho!");
}

function carregarCarrinho() {
    const lista = document.getElementById("listaCarrinho");
    const totalEl = document.getElementById("total");

    if (!lista) return;

    lista.innerHTML = "";
    let total = 0;

    carrinho.forEach(prod => {
        total += prod.preco;

        lista.innerHTML += `
      <div class="flex justify-between bg-white p-4 rounded shadow">
        <span>${prod.nome}</span>
        <span>R$ ${prod.preco.toFixed(2)}</span>
      </div>
    `;
    });

    totalEl.innerText = "Total: R$ " + total.toFixed(2);
}