const API = "http://localhost:8080/api/categorias";

const container = document.getElementById("listaCategorias");

async function carregarCategorias() {
    try {
        const res = await fetch(API);

        if (!res.ok) {
            throw new Error("Erro ao buscar categorias");
        }

        const categorias = await res.json();

        container.innerHTML = "";

        if (!categorias || categorias.length === 0) {
            container.innerHTML = `
                <p class="col-span-full text-center text-gray-500">
                    Nenhuma categoria cadastrada.
                </p>
            `;
            return;
        }

        let html = "";

        categorias.forEach(cat => {
            html += `
                <a href="descricaoprodutos.html?categoria=${cat.id}"
                    class="group bg-white p-4 rounded-2xl shadow hover:shadow-xl transition text-center">

                    <div class="h-36 rounded-xl overflow-hidden bg-gray-100 flex items-center justify-center">
                        <img src="${cat.imagem || 'https://via.placeholder.com/300'}"
                            class="w-full h-full object-cover group-hover:scale-110 transition">
                    </div>

                    <h3 class="mt-3 font-semibold text-gray-800">
                        ${cat.nome}
                    </h3>
                </a>
            `;
        });

        container.innerHTML = html;

    } catch (erro) {
        console.error(erro);

        container.innerHTML = `
            <p class="col-span-full text-center text-red-500">
                Erro ao carregar categorias.
            </p>
        `;
    }
}

carregarCategorias();