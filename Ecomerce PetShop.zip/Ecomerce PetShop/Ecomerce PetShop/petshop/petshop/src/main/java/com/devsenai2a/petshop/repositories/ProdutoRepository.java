package com.devsenai2a.petshop.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import com.devsenai2a.petshop.entities.Produto;

public interface ProdutoRepository extends JpaRepository<Produto, Long> {

}