package com.devsenai2a.petshop.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.devsenai2a.petshop.entities.Produto;
import com.devsenai2a.petshop.repositories.ProdutoRepository;

@Service
public class ProdutoService {

    @Autowired
    private ProdutoRepository repository;

    public Produto salvar(Produto produto) {
        return repository.save(produto);
    }

    public List<Produto> listar() {
        return repository.findAll();
    }

    public Produto buscarPorId(Long id) {
        return repository.findById(id).orElse(null);
    }

    public Produto atualizar(Long id, Produto produtoAtualizado) {
        Produto existente = buscarPorId(id);

        if (existente != null) {
            existente.setNome(produtoAtualizado.getNome());
            existente.setDescricao(produtoAtualizado.getDescricao());
            existente.setPreco(produtoAtualizado.getPreco());
            existente.setPrecoDesconto(produtoAtualizado.getPrecoDesconto());
            existente.setImagem(produtoAtualizado.getImagem());
            existente.setQtdEstoque(produtoAtualizado.getQtdEstoque());
            existente.setAtivo(produtoAtualizado.getAtivo());
            existente.setCategoria(produtoAtualizado.getCategoria());

            return repository.save(existente);
        }

        return null;
    }

    public void deletar(Long id) {
        repository.deleteById(id);
    }
}