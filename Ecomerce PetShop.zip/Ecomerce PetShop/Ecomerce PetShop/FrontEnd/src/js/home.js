const API = "http://localhost:8080/categorias";

const lista = document.getElementById("lista");
const form = document.getElementById("formCategoria");

const idInput = document.getElementById("id");
const nomeInput = document.getElementById("nome");
const descricaoInput = document.getElementById("descricao");

// 🔹 LISTAR
function listar() {
    fetch(API)
        .then(res => res.json())
        .then(data => {
            lista.innerHTML = "";

            data.forEach(cat => {
                const li = document.createElement("li");

                li.innerHTML = `
                            <b>${cat.nome}</b> - ${cat.descricao || ""}
                            <button onclick="editar(${cat.id_categoria}, '${cat.nome}', '${cat.descricao}')">Editar</button>
                            <button onclick="excluir(${cat.id_categoria})">Excluir</button>
                        `;

                lista.appendChild(li);
            });
        });
}

// 🔹 SALVAR (POST ou PUT)
form.addEventListener("submit", function (e) {
    e.preventDefault();

    const categoria = {
        nome: nomeInput.value,
        descricao: descricaoInput.value
    };

    const id = idInput.value;

    if (id) {
        // UPDATE
        fetch(`${API}/${id}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(categoria)
        }).then(() => {
            limpar();
            listar();
        });
    } else {
        // CREATE
        fetch(API, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(categoria)
        }).then(() => {
            limpar();
            listar();
        });
    }
});

// 🔹 EDITAR
function editar(id, nome, descricao) {
    idInput.value = id;
    nomeInput.value = nome;
    descricaoInput.value = descricao;
}

// 🔹 EXCLUIR
function excluir(id) {
    if (!confirm("Tem certeza que deseja excluir?")) return;

    fetch(`${API}/${id}`, {
        method: "DELETE"
    })
        .then(res => {
            console.log("STATUS:", res.status);

            if (!res.ok) {
                return res.text().then(text => {
                    throw new Error(text);
                });
            }

            listar();
        })
        .catch(err => {
            console.error("ERRO AO EXCLUIR:", err);
            alert("Erro ao excluir!");
        });
}

// 🔹 LIMPAR FORM
function limpar() {
    idInput.value = "";
    nomeInput.value = "";
    descricaoInput.value = "";
}

// 🔥 INICIAR
listar();