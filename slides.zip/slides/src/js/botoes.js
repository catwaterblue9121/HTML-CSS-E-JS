
const slides = document.querySelectorAll(".slide");
let slideAtual = 0;


function mostrarSlide(index) {
    slides.forEach((slide, i) => {
        slide.style.display = i === index ? "block" : "none";
    });
}

function proximoSlide() {
    slideAtual = (slideAtual + 1) % slides.length;
    mostrarSlide(slideAtual);
}

function anteriorSlide() {
    slideAtual = (slideAtual - 1 + slides.length) % slides.length;
    mostrarSlide(slideAtual);
}

document.querySelectorAll(".next").forEach(btn => {
    btn.addEventListener("click", proximoSlide);
});

document.querySelectorAll(".prev").forEach(btn => {
    btn.addEventListener("click", anteriorSlide);
});

document.addEventListener("keydown", (event) => {
    if (event.key === "ArrowRight") {
        proximoSlide();
    } else if (event.key === "ArrowLeft") {
        anteriorSlide(); 
    }
});

mostrarSlide(slideAtual);
